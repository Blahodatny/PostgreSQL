create function make_tsvector_pr(product_id text, producttype text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (SETWEIGHT(TO_TSVECTOR('english', Product_ID), 'D')) ||
         SETWEIGHT(TO_TSVECTOR('english', ProductType), 'D');
END
$$;

alter function make_tsvector_pr(text, text) owner to postgres;

