create function make_tsvector_ord(tostreet text, tocity text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (setweight(to_tsvector('english', ToStreet), 'D')) ||
         setweight(to_tsvector('english', ToCity), 'D');
END
$$;

alter function make_tsvector_ord(text, text) owner to postgres;

