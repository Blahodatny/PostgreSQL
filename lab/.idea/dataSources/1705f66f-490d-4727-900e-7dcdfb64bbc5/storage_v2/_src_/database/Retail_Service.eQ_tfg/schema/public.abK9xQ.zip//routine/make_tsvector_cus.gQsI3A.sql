create function make_tsvector_cus(phone text, firstname text, lastname text, street text, city text) returns tsvector
  immutable
  language plpgsql
as
$$
BEGIN
  RETURN (setweight(to_tsvector('english', Phone), 'A')) ||
         setweight(to_tsvector('english', FirstName), 'B') ||
         setweight(to_tsvector('english', LastName), 'B') ||
         setweight(to_tsvector('english', Street), 'C') ||
         setweight(to_tsvector('english', City), 'C');
END
$$;

alter function make_tsvector_cus(text, text, text, text, text) owner to postgres;

